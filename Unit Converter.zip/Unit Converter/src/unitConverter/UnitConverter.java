package unitConverter;
import javax.swing.*;
import java.awt.event.*;
public class UnitConverter {
    private JFrame frame;
    private JLabel inputLable,outputLable;
    private JTextField input;
    private JTextField output;
    private JComboBox<String> fromUnit;
    private JComboBox<String> toUnit;
    private JButton convertButton;
    protected void initComponents(){
        frame=new JFrame("Unit Converter");
        frame.setSize(400,150);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        inputLable=new JLabel("Input: ");
        input = new JTextField(10);
        outputLable= new JLabel("output");
        output= new JTextField(10);
        output.setEnabled(false);
        fromUnit=new JComboBox<String>(new String[]{"Meters","Feet","Inches","Centimeters"});
        toUnit=new JComboBox<String>(new String[]{"Meters","Feet","Inches","Centimeters"});
        convertButton=new JButton("Convert");

        inputLable.setBounds(20,20,100,20);
        input.setBounds(150,20,100,20);
        fromUnit.setBounds(270,20,100,20);
        outputLable.setBounds(20,50,100,20);
        output.setBounds(150,50,100,20);
        toUnit.setBounds(270,50,100,20);
        convertButton.setBounds(150,80,100,20);

        convertButton.addActionListener(new ConvertButtonListener());


        frame.add(inputLable);
        frame.add(input);
        frame.add(fromUnit);
        frame.add(outputLable);
        frame.add(output);
        frame.add(toUnit);
        frame.add(convertButton);

        frame.setVisible(true);


    }

    public UnitConverter(){
        initComponents();

    }
    public static void main (String [] args){
        new UnitConverter();
    }
    private class ConvertButtonListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            String fromUnitType=fromUnit.getSelectedItem().toString();
            String toUnitType= toUnit.getSelectedItem().toString();
            double inputValue=Double.parseDouble(input.getText());
            double outputValue=0.0;
            if(fromUnitType.equals("Meters")){
                if(toUnitType.equals("Meters")){
                    outputValue=UnitConverter.metersTOMeters(inputValue);
                }
                else if (toUnitType.equals("Feet")) {
                    outputValue=UnitConverter.metersTOFeet(inputValue);
                }
                else if (toUnitType.equals("Inches")) {
                    outputValue=UnitConverter.metersTOInches(inputValue);
                }
                else if (toUnitType.equals("Centimeters")) {
                    outputValue=UnitConverter.metersTOCentimeters(inputValue);

                }
            }
            else if (fromUnitType.equals("Feet")) {
                if(toUnitType.equals("Meters")){
                    outputValue=UnitConverter.feetTOMeters(inputValue);
                }
                else if (toUnitType.equals("Feet")) {
                    outputValue=UnitConverter.feetTOFeet(inputValue);
                }
                else if (toUnitType.equals("Inches")) {
                    outputValue=UnitConverter.feetTOInches(inputValue);
                }
                else if (toUnitType.equals("Centimeters")) {
                    outputValue=UnitConverter.feetTOCentimeters(inputValue);

                }
            }
            else if (fromUnitType.equals("Inches")) {
                if(toUnitType.equals("Meters")){
                    outputValue=UnitConverter.inchesTOMeters(inputValue);
                }
                else if (toUnitType.equals("Feet")) {
                    outputValue=UnitConverter.inchsTOFeet(inputValue);
                }
                else if (toUnitType.equals("Inches")) {
                    outputValue=UnitConverter.inchsTOInches(inputValue);
                }
                else if (toUnitType.equals("Centimeters")) {
                    outputValue=UnitConverter.inchsTOCentimeters(inputValue);
                }
            }
            else if (fromUnitType.equals("Centimeters")){
                if(toUnitType.equals("Meters")){
                    outputValue=UnitConverter.centiMetersTOMeters(inputValue);
                }
                else if (toUnitType.equals("Feet")) {
                    outputValue=UnitConverter.centiMetersTOFeet(inputValue);
                }
                else if (toUnitType.equals("Inches")) {
                    outputValue=UnitConverter.centiMetersTOInches(inputValue);
                }
                else if (toUnitType.equals("Centimeters")) {
                    outputValue=UnitConverter.centiMetersTOCentimeters(inputValue);

                }
            }
             output.setText(" "+outputValue);
        }
    }
    public static double metersTOMeters(double inputValue){
        double outputValue;
        outputValue=inputValue;
        return outputValue;
    }
    public static double metersTOCentimeters(double inputValue){
        double outputValue;
        outputValue=inputValue*100;
        return outputValue;
    }
    public static double metersTOFeet(double inputValue){
        double outputValue;
        outputValue=inputValue*3.28084;
        return outputValue;
    }
    public static double metersTOInches(double inputValue){
        double outputValue;
        outputValue=inputValue*3.28084*12;
        return outputValue;
    }
    public static double feetTOMeters(double inputValue){
        double outputValue;
        outputValue=inputValue/3.28084;
        return outputValue;
    }
    public static double feetTOCentimeters(double inputValue){
        double outputValue;
        outputValue=inputValue/3.28084*100;
        return outputValue;
    }
    public static double feetTOFeet(double inputValue){
        double outputValue;
        outputValue=inputValue;
        return outputValue;
    }
    public static double feetTOInches(double inputValue){
        double outputValue;
        outputValue=inputValue*12;
        return outputValue;
    }
    public static double inchesTOMeters(double inputValue){
        double outputValue;
        outputValue=inputValue/12/3.28084;
        return outputValue;
    }
    public static double inchsTOCentimeters(double inputValue){
        double outputValue;
        outputValue=inputValue/12/3.28084*100;
        return outputValue;
    }
    public static double inchsTOFeet(double inputValue){
        double outputValue;
        outputValue=inputValue/12;
        return outputValue;
    }
    public static double inchsTOInches(double inputValue){
        double outputValue;
        outputValue=inputValue;
        return outputValue;
    }
    public static double centiMetersTOMeters(double inputValue){
        double outputValue;
        outputValue=inputValue/100;
        return outputValue;
    }
    public static double centiMetersTOCentimeters(double inputValue){
        double outputValue;
        outputValue=inputValue;
        return outputValue;
    }
    public static double centiMetersTOFeet(double inputValue){
        double outputValue;
        outputValue=inputValue/100*3.28084;
        return outputValue;
    }
    public static double centiMetersTOInches(double inputValue){
        double outputValue;
        outputValue=inputValue/100*3.28084*12;
        return outputValue;
    }
}
